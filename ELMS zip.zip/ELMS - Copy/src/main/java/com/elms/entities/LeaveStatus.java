package com.elms.entities;

public enum LeaveStatus {
    REJECTED,
    ACCEPTED,
    CANCELLED,
    APPROVED
}
